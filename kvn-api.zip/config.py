SECRET_KEY = 'Chave'

DEBUG = True

DB_HOST = 'localhost'
DB_NAME = r'C:\Lucas Silva Gajardoni\BANCOS\BANCOBIBLIOTECA.FDB'

DB_USER = 'sysdba'
DB_PASSWORD = 'sysdba'

