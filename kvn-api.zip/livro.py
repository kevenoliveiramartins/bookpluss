import jwt
from flask import jsonify, request, Response
from main import app, con
from funcao import gerar_token, remover_bearer
from fpdf import FPDF
from flask import send_file
import os
import pygal
import jwt

@app.route('/livro', methods=['GET'])
def livro():
    # token = request.headers.get('Authorization')
    token = request.cookies.get('access_token')
    if not token:
        return jsonify({'message': 'token necessario'}), 401
    token = remover_bearer(token)

    try:
        payload = jwt.decode(token, app.config['SECRET_KEY'], algorithms=['HS256'])
    except jwt.ExpiredSignatureError:
        return jsonify({'message': 'token expirado'}), 401
    except jwt.InvalidTokenError:
        return jsonify({'message': 'token invalido'}), 401
    try:
        cursor = con.cursor()
        cursor.execute('SELECT id_livro, titulo, autor, ano_publicacao FROM livros')
        livros = cursor.fetchall()
        livros_lista = []
        for livro in livros:
            livros_lista.append({
                'id_livro':livro[0]
                , 'titulo':livro[1]
                , 'autor':livro[2]
                , 'ano_publicacao':livro[3]
            })
        return jsonify(mensagem='lista de livros', livros=livros_lista)
    except Exception as e:
        return jsonify(mensagem= f"DEU RUIM COM FORÇA: {e}"), 500
    finally:
        cursor.close()

@app.route('/adicionar_livro', methods=['POST'])
def adicionar_livro():

    token = request.headers.get('Authorization')
    if not token:
        return jsonify({'message': 'token necessario'}), 401
    token = remover_bearer(token)

    try:
        payload = jwt.decode(token, app.config['SECRET_KEY'], algorithms=['HS256'])
    except jwt.ExpiredSignatureError:
        return jsonify({'message': 'token expirado'}), 401
    except jwt.InvalidTokenError:
        return jsonify({'message': 'token invalido'}), 401

    titulo = request.form.get('titulo')
    autor = request.form.get('autor')
    ano_publicacao = request.form.get('ano_publicacao')
    imagem = request.files.get('imagem')

    try:
        cursor = con.cursor()

        cursor.execute("SELECT 1 FROM LIVROS WHERE TITULO = ?", (titulo,))
        if cursor.fetchone():
            return jsonify(mensagem="JA TEM COM ESSE NOME ANIMAL"), 400

        cursor.execute("""
            INSERT INTO LIVROS (TITULO, AUTOR, ANO_PUBLICACAO)
            VALUES (?, ?, ?)
            RETURNING ID_LIVRO
        """, (titulo, autor, ano_publicacao))

        id_livro = cursor.fetchone()[0]
        con.commit()

        if imagem:
            pasta_livros = os.path.join(app.config['UPLOAD_FOLDER'], "livros")
            os.makedirs(pasta_livros, exist_ok=True)

            caminho_imagem = os.path.join(pasta_livros, f"{id_livro}.jpg")
            imagem.save(caminho_imagem)

        return jsonify({
            'message': 'livro cadastrado com sucesso',
            'id_livro': id_livro
        }), 201

    except Exception as e:
        return jsonify(mensagem=f"Deu ruim: {e}"), 500

    finally:
        cursor.close()

@app.route('/editar_livro/<int:id_livro>', methods=['put'])
def editar_livro(id_livro):
    cursor = con.cursor()
    cursor.execute("""select ID_LIVRO, titulo, autor, ano_publicacao
                      FROM LIVROS
                      where ID_LIVRO = ?""",(id_livro,))
    livro_true = cursor.fetchone()
    if not livro_true:
        cursor.close()
        return jsonify({'mensagem':'Livro nao encontrado'}),404

    data = request.get_json()
    titulo = data.get('titulo')
    autor = data.get('autor')
    ano_publicacao = data.get('ano_publicacao')

    cursor.execute("""update LIVROS set titulo = ?, autor = ?, ano_publicacao = ?
                        where id_livro = ? """, (titulo, autor, ano_publicacao, id_livro))
    con.commit()
    cursor.close()
    return jsonify({'message':'livro editado com sucesso',
                    'livro':{
                    'id_livro':id_livro,
                    'titulo':titulo,
                    'autor':autor,
                    'ano_publicacao':ano_publicacao}
                    })

@app.route('/eliminar_livro/<int:id_livro>', methods=['delete'])
def eliminar_livro(id_livro):

    cursor = con.cursor()

    cursor.execute("""select ID_LIVRO, titulo, autor, ano_publicacao
                          FROM LIVROS
                          where ID_LIVRO = ?""", (id_livro,))
    livro_true = cursor.fetchone()
    if not livro_true:
        cursor.close()
        return jsonify({'mensagem': 'Livro nao encontrado'}), 404
    cursor.execute("""delete from LIVROS where id_livro = ? """,(id_livro,))
    con.commit()
    cursor.close()
    return jsonify({'message':'livro eliminado com sucesso',})


@app.route('/relatorio_livro', methods=['GET'])
def relatorio_livro():
    try:
        cursor = con.cursor()
        cursor.execute('SELECT id_livro, titulo FROM LIVROS')
        livros = cursor.fetchall()

        pdf = FPDF()
        pdf.add_page()
        pdf.set_font("Arial", size=12)

        # Título
        pdf.cell(200, 10, txt="Relatorio De Livros", ln=True, align='C')
        pdf.ln(10)

        # Cabeçalho da tabela
        pdf.cell(40, 10, "ID", 1)
        pdf.cell(100, 10, "Titulo", 1)
        pdf.ln()

        # Dados
        for x in livros:
            pdf.cell(40, 10, str(x[0]), 1)
            pdf.cell(100, 10, x[1], 1)
            pdf.ln()

        caminho_arquivo = "relatorio_Livros.pdf"
        pdf.output(caminho_arquivo)

        return send_file(caminho_arquivo, as_attachment=True)

    except Exception as e:
        return jsonify({'mensagem': f'Deu ruim no relatorio: {e}'}), 500

    finally:
        cursor.close()


@app.route('/grafico', methods=['GET'])
def grafico():
    cursor = con.cursor()
    cursor.execute("""SELECT ano_publicacao, count(*) FROM LIVROS
                        group by ano_publicacao
                        ORDER BY ano_publicacao""")
    resultado = cursor.fetchall()
    cursor.close()

    grafico = pygal.Bar()
    grafico.title = 'Grafico de livros ano'

    for i in resultado:
        grafico.add(str(i[0]), i[1])
    return Response(grafico.render(), mimetype='image/svg+xml'), 200

