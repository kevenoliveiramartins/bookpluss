import fdb

class LIVROS:
    def __init__(self,ID_LIVRO, TITULO,AUTOR,ANO_PUBLICACAO):
        self.ID_LIVRO = ID_LIVRO
        self.TITULO = TITULO
        self.AUTOR = AUTOR
        self.ANO_PUBLICACAO = ANO_PUBLICACAO