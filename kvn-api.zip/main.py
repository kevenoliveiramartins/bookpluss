from flask import Flask
import fdb
import os
from flask_bcrypt import Bcrypt
from flask_cors import CORS
app = Flask(__name__)
bcrypt = Bcrypt(app)
CORS(app, origins="*")


UPLOAD_FOLDER = 'uploads'
app.config['UPLOAD_FOLDER'] = UPLOAD_FOLDER

if not os.path.exists(UPLOAD_FOLDER):
    os.makedirs(UPLOAD_FOLDER)


app.config.from_pyfile('config.py')

host = app.config['DB_HOST']
databese = app.config['DB_NAME']
user = app.config['DB_USER']
password = app.config['DB_PASSWORD']



try:
    con = fdb.connect(host=host, database=databese, user=user, password=password)
    print("DEU BOM")

except Exception as e:
        print(f"DEU RUIM : {e}")


from livro import *
from usuario import *

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=5000)