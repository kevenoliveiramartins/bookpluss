import threading
import smtplib
from email.mime.text import MIMEText
import jwt
import datetime
from flask_bcrypt import generate_password_hash
from main import app
from main import bcrypt

def validar_senha(senha):
    maiuscula = False
    minuscula = False
    numero = False
    caracterpcd = False

    for s in senha:
        if s.isupper():
            maiuscula = True
        if s.islower():
            minuscula = True
        if s.isdigit():
            numero = True
        if not s.isalnum():
            caracterpcd = True

    if not (maiuscula and minuscula and numero and caracterpcd):
        return False
    return True


def criptografar_senha(senha):
    return bcrypt.generate_password_hash(senha).decode('utf-8')


def enviar_mensagem(destinatario, assunto, mensagem):
    user = 'lucasgajardoni61@gmail.com'
    senha = 'vxce xqyr smtn lckd'
    msg = MIMEText(mensagem)
    msg['Subject'] = assunto
    msg['From'] = user
    msg['To'] = destinatario

    server = smtplib.SMTP('smtp.gmail.com', 587)
    server.starttls()
    server.login(user, senha)
    server.send_message(msg)
    server.quit()

def gerar_token(id_usuario):
    payload = {'id_usuario': id_usuario,
               'exp': datetime.datetime.utcnow() + datetime.timedelta(minutes=30),}
    token = jwt.encode(payload, app.config['SECRET_KEY'], algorithm='HS256')
    return token

def remover_bearer(token):
    if token.startswith('Bearer '):
        return token[len('Bearer '):]
    else:
        return token