from flask import jsonify, request, make_response
from main import app, con
from funcao import validar_senha, criptografar_senha, enviar_mensagem, gerar_token, remover_bearer
from main import bcrypt
from fpdf import FPDF
from flask import send_file
import threading


@app.route('/usuario', methods=['GET'])
def usuario():
    try:
        cursor = con.cursor()
        cursor.execute('SELECT id_usuario, nome_usuario FROM USUARIOS')
        usuarios = cursor.fetchall()

        lista_usuarios = []
        for usuario in usuarios:
            lista_usuarios.append({
                'id_usuario': usuario[0],
                'nome_usuario': usuario[1]
            })

        return jsonify(mensagem='lista de usuarios', usuarios=lista_usuarios)

    except Exception as e:
        return jsonify(mensagem=f"DEU RUIM COM FORÇA: {e}"), 500
    finally:
        cursor.close()
@app.route('/adicionar_usuario', methods=['POST'])
def adicionar_usuario():
        dados = request.get_json()
        nome_usuario = dados.get('nome_usuario')
        senha = dados.get('senha')

        try:
            cursor = con.cursor()
            cursor.execute("SELECT 1 FROM USUARIOS WHERE NOME_USUARIO = ?", (nome_usuario,))
            if cursor.fetchone():
                return jsonify(mensagem="JA TEM ESSE NOME"), 400

            senha_valida = validar_senha(senha)
            if not senha_valida:
                return jsonify(mensagem ='SENHA FRACA'), 400

            senha_criptografada = criptografar_senha(senha)
            cursor.execute(""" INSERT INTO USUARIOS (NOME_USUARIO, SENHA) VALUES (?, ?)""", (nome_usuario, senha_criptografada))
            con.commit()

            return jsonify({
                    'message': 'usuario cadastrado com sucesso'}), 201
        except Exception as e:
            return jsonify(mensagem="Deu ruim no adicionar usuario"), 500
        finally:
            cursor.close()


@app.route('/editar_usuario/<int:id_usuario>', methods=['PUT'])
def editar_usuario(id_usuario):
    cursor = con.cursor()
    cursor.execute("""SELECT ID_USUARIO, NOME_USUARIO FROM USUARIOS WHERE ID_USUARIO = ?""", (id_usuario,))
    usuario_true = cursor.fetchone()
    if not usuario_true:
        cursor.close()
        return jsonify({'mensagem': 'Usuario nao encontrado'}), 404


    dados = request.get_json()

    nome_usuario = dados.get('nome_usuario')
    senha = dados.get('senha')

    senha_valida = validar_senha(senha)

    if not senha_valida:
        cursor.close()
        return jsonify({'mensagem':'coloqueuma senha valida'}), 400

    senha_criptografada = criptografar_senha(senha)

    cursor.execute(""" UPDATE USUARIOS SET NOME_USUARIO = ?, SENHA = ? WHERE ID_USUARIO = ? """, (nome_usuario, senha_criptografada, id_usuario))

    con.commit()
    cursor.close()

    return jsonify({
        'message': 'usuario editado com sucesso',
    })

@app.route('/eliminar_usuario/<int:id_usuario>', methods=['DELETE'])
def eliminar_usuario(id_usuario):
    cursor = con.cursor()

    cursor.execute("""SELECT ID_USUARIO FROM USUARIOS WHERE ID_USUARIO = ?""", (id_usuario,))
    usuario_true = cursor.fetchone()
    if not usuario_true:
        cursor.close()
        return jsonify({'mensagem': 'Usuario nao encontrado'}), 404

    cursor.execute("""DELETE FROM USUARIOS WHERE ID_USUARIO = ?""", (id_usuario,))

    con.commit()
    cursor.close()
    return jsonify({'message': 'usuario eliminado com sucesso'})


# @app.route('/login', methods=['POST'])
# def login():
#     dados = request.get_json()
#     nome_usuario = dados.get('nome_usuario')
#     senha = dados.get('senha')
#
#     try:
#         cursor = con.cursor()
#
#         cursor.execute("""SELECT ID_USUARIO, NOME_USUARIO, SENHA FROM USUARIOS WHERE NOME_USUARIO = ? """, (nome_usuario,))
#         tem_usuario = cursor.fetchone()
#         print(tem_usuario)
#         if not tem_usuario:
#             return jsonify({'mensagem': 'Usuario ou senha invalida'}), 401
#
#         senha_escritanobanco = tem_usuario[2]
#         id_usuario = tem_usuario[0]
#
#         if not bcrypt.check_password_hash(senha_escritanobanco, senha):
#             return jsonify({'mensagem': 'Usuario ou senha invalida'}), 401
#
#         token = gerar_token(id_usuario)
#         return jsonify({
#             'message': 'login realizado com sucesso' ,'token': token
#         }), 200
#
#     except Exception as e:
#         return jsonify({'mensagem': 'Deu ruim no login'}), 500
#     finally:
#         cursor.close()

@app.route('/relatorio_usuarios', methods=['GET'])
def relatorio_usuarios():
    try:
        cursor = con.cursor()
        cursor.execute('SELECT id_usuario, nome_usuario FROM USUARIOS')
        usuarios = cursor.fetchall()

        pdf = FPDF()
        pdf.add_page()
        pdf.set_font("Arial", size=12)

        # Título
        pdf.cell(200, 10, txt="Relatorio de Usuarios", ln=True, align='C')
        pdf.ln(10)

        # Cabeçalho da tabela
        pdf.cell(40, 10, "ID", 1)
        pdf.cell(100, 10, "Nome do Usuario", 1)
        pdf.ln()

        # Dados
        for usuario in usuarios:
            pdf.cell(40, 10, str(usuario[0]), 1)
            pdf.cell(100, 10, usuario[1], 1)
            pdf.ln()

        # Salvar arquivo
        caminho_arquivo = "relatorio_usuarios.pdf"
        pdf.output(caminho_arquivo)

        return send_file(caminho_arquivo, as_attachment=True)

    except Exception as e:
        return jsonify({'mensagem': f'Deu ruim no relatorio: {e}'}), 500

    finally:
        cursor.close()


@app.route('/envia_email', methods=['POST'])
def envia_email():
    dados = request.json

    assunto = dados.get('subject')
    mensagem = dados.get('mensagem')
    destinatario = dados.get('to')

    thread = threading.Thread(target=enviar_mensagem,args=(destinatario, assunto, mensagem,))
    thread.start()

    return jsonify({'status': 'Email enviado com sucesso!'}), 200

@app.route('/login', methods=['POST'])
def login():
    dados = request.get_json()
    nome_usuario = dados.get('nome_usuario')
    senha = dados.get('senha')

    try:
        cursor = con.cursor()

        cursor.execute("""SELECT ID_USUARIO, NOME_USUARIO, SENHA FROM USUARIOS WHERE NOME_USUARIO = ? """, (nome_usuario,))
        tem_usuario = cursor.fetchone()
        print(tem_usuario)
        if not tem_usuario:
            return jsonify({'mensagem': 'Usuario ou senha invalida'}), 401

        senha_escritanobanco = tem_usuario[2]
        id_usuario = tem_usuario[0]

        if not bcrypt.check_password_hash(senha_escritanobanco, senha):
            return jsonify({'mensagem': 'Usuario ou senha invalida'}), 401


        token = gerar_token(id_usuario)
        resposta = make_response(jsonify({'mensagem': 'login com sucesso'}), 200)
        resposta.set_cookie('access_token', token,
                            httponly=True,
                            secure=False,
                            samesite='Lax',
                            path="/",
                            max_age=3600)
        return resposta


        # return jsonify({
        #     'message': 'login realizado com sucesso' ,'token': token
        # }), 200

    except Exception as e:
        return jsonify({'mensagem': 'Deu ruim no login'}), 500
    finally:
        cursor.close()






